using SLFMS.Domain.Common;

namespace SLFMS.Domain.Claims.ValueObjects;

public sealed class ClaimDocument : ValueObject
{
    public string FileName { get; }
    public string FileUrl { get; }
    public string ContentType { get; }
    public long FileSizeBytes { get; }
    public DateTime UploadedAt { get; }

    private ClaimDocument(string fileName, string fileUrl, string contentType, long fileSizeBytes, DateTime uploadedAt)
    {
        FileName = fileName;
        FileUrl = fileUrl;
        ContentType = contentType;
        FileSizeBytes = fileSizeBytes;
        UploadedAt = uploadedAt;
    }

    public static ClaimDocument Create(string fileName, string fileUrl, string contentType, long fileSizeBytes)
    {
        if (string.IsNullOrWhiteSpace(fileName))
            throw new ArgumentException("File name is required.", nameof(fileName));

        if (string.IsNullOrWhiteSpace(fileUrl))
            throw new ArgumentException("File URL is required.", nameof(fileUrl));

        if (fileSizeBytes <= 0)
            throw new ArgumentException("File size must be greater than zero.", nameof(fileSizeBytes));

        // Max 10MB
        const long maxSizeBytes = 10 * 1024 * 1024;
        if (fileSizeBytes > maxSizeBytes)
            throw new ArgumentException("File size cannot exceed 10MB.", nameof(fileSizeBytes));

        return new ClaimDocument(fileName, fileUrl, contentType, fileSizeBytes, DateTime.UtcNow);
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return FileUrl;
    }

    public override string ToString() => $"{FileName} ({FileSizeBytes / 1024}KB)";
}
