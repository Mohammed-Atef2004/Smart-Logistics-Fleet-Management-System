using SLFMS.Domain.Common;

namespace SLFMS.Domain.Claims.ValueObjects;

public sealed class ClaimNumber : ValueObject
{
    public string Value { get; }

    private ClaimNumber(string value) => Value = value;

    public static ClaimNumber Generate()
    {
        // Format: CLM-YYYYMMDD-XXXXXXXX
        var datePart = DateTime.UtcNow.ToString("yyyyMMdd");
        var randomPart = Guid.NewGuid().ToString("N")[..8].ToUpper();
        return new ClaimNumber($"CLM-{datePart}-{randomPart}");
    }

    public static ClaimNumber From(string value)
    {
        if (string.IsNullOrWhiteSpace(value))
            throw new ArgumentException("Claim number cannot be empty.", nameof(value));

        return new ClaimNumber(value);
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Value;
    }

    public override string ToString() => Value;
}
