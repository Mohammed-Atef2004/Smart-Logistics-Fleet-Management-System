using SLFMS.Application.Common.Abstractions;
using SLFMS.Application.Common.Models;
using SLFMS.Domain.Claims;
using SLFMS.Domain.Claims.Enums;

namespace SLFMS.Application.Claims.Queries.GetPendingClaims;

// ======================== Query ========================

public sealed record GetPendingClaimsQuery : IQuery<Result<IReadOnlyList<ClaimSummaryDto>>>;

// ======================== Handler ========================

public sealed class GetPendingClaimsHandler : IQueryHandler<GetPendingClaimsQuery, Result<IReadOnlyList<ClaimSummaryDto>>>
{
    private readonly IClaimRepository _repository;

    public GetPendingClaimsHandler(IClaimRepository repository) => _repository = repository;

    public async Task<Result<IReadOnlyList<ClaimSummaryDto>>> Handle(
        GetPendingClaimsQuery query,
        CancellationToken cancellationToken)
    {
        // Pending = Submitted + UnderReview
        var submitted = await _repository.GetByStatusAsync(ClaimStatus.Submitted, cancellationToken);
        var underReview = await _repository.GetByStatusAsync(ClaimStatus.UnderReview, cancellationToken);

        var allPending = submitted.Concat(underReview)
            .OrderBy(c => c.SubmittedAt)
            .Select(c => new ClaimSummaryDto(
                c.Id.Value,
                c.ClaimNumber.Value,
                c.ShipmentId,
                c.CustomerId,
                c.Status.ToString(),
                c.ClaimAmount.Amount,
                c.ClaimAmount.Currency,
                c.SubmittedAt))
            .ToList();

        return Result.Success<IReadOnlyList<ClaimSummaryDto>>(allPending);
    }
}
