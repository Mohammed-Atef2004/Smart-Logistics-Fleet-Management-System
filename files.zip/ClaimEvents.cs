using SLFMS.Domain.Claims.ValueObjects;
using SLFMS.Domain.Common;
using SLFMS.Domain.SharedKernel;

namespace SLFMS.Domain.Claims.Events;

public sealed record ClaimSubmittedEvent(
    ClaimId ClaimId,
    Guid ShipmentId,
    Guid CustomerId,
    Money ClaimAmount) : DomainEvent;

public sealed record ClaimUnderReviewEvent(
    ClaimId ClaimId) : DomainEvent;

public sealed record ClaimApprovedEvent(
    ClaimId ClaimId,
    Guid CustomerId,
    Money ApprovedAmount) : DomainEvent;

public sealed record ClaimRejectedEvent(
    ClaimId ClaimId,
    Guid CustomerId,
    string Reason) : DomainEvent;

public sealed record ClaimPaymentProcessedEvent(
    ClaimId ClaimId,
    Guid CustomerId,
    Money PaidAmount) : DomainEvent;

public sealed record ClaimClosedEvent(
    ClaimId ClaimId) : DomainEvent;
