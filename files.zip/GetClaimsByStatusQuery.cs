using SLFMS.Application.Common.Abstractions;
using SLFMS.Application.Common.Models;
using SLFMS.Domain.Claims;
using SLFMS.Domain.Claims.Enums;

namespace SLFMS.Application.Claims.Queries.GetClaimsByStatus;

// ======================== Query ========================

public sealed record GetClaimsByStatusQuery(ClaimStatus Status) : IQuery<Result<IReadOnlyList<ClaimSummaryDto>>>;

// ======================== Handler ========================

public sealed class GetClaimsByStatusHandler : IQueryHandler<GetClaimsByStatusQuery, Result<IReadOnlyList<ClaimSummaryDto>>>
{
    private readonly IClaimRepository _repository;

    public GetClaimsByStatusHandler(IClaimRepository repository) => _repository = repository;

    public async Task<Result<IReadOnlyList<ClaimSummaryDto>>> Handle(
        GetClaimsByStatusQuery query,
        CancellationToken cancellationToken)
    {
        var claims = await _repository.GetByStatusAsync(query.Status, cancellationToken);

        var dtos = claims
            .Select(c => new ClaimSummaryDto(
                c.Id.Value,
                c.ClaimNumber.Value,
                c.ShipmentId,
                c.CustomerId,
                c.Status.ToString(),
                c.ClaimAmount.Amount,
                c.ClaimAmount.Currency,
                c.SubmittedAt))
            .ToList();

        return Result.Success<IReadOnlyList<ClaimSummaryDto>>(dtos);
    }
}
