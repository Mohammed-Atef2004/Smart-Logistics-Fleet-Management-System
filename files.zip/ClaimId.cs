using SLFMS.Domain.Common;

namespace SLFMS.Domain.Claims.ValueObjects;

public sealed class ClaimId : ValueObject
{
    public Guid Value { get; }

    private ClaimId(Guid value) => Value = value;

    public static ClaimId New() => new(Guid.NewGuid());

    public static ClaimId From(Guid value)
    {
        if (value == Guid.Empty)
            throw new ArgumentException("ClaimId cannot be empty.", nameof(value));

        return new ClaimId(value);
    }

    protected override IEnumerable<object> GetEqualityComponents()
    {
        yield return Value;
    }

    public override string ToString() => Value.ToString();
}
