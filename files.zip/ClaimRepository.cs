using Microsoft.EntityFrameworkCore;
using SLFMS.Domain.Claims;
using SLFMS.Domain.Claims.Enums;
using SLFMS.Domain.Claims.ValueObjects;
using SLFMS.Infrastructure.Persistence;

namespace SLFMS.Infrastructure.Claims;

public sealed class ClaimRepository : IClaimRepository
{
    private readonly ApplicationDbContext _context;

    public ClaimRepository(ApplicationDbContext context) => _context = context;

    public async Task<InsuranceClaim?> GetByIdAsync(
        ClaimId id,
        CancellationToken cancellationToken = default)
    {
        return await _context.InsuranceClaims
            .FirstOrDefaultAsync(c => c.Id == id, cancellationToken);
    }

    public async Task<InsuranceClaim?> GetByClaimNumberAsync(
        ClaimNumber claimNumber,
        CancellationToken cancellationToken = default)
    {
        return await _context.InsuranceClaims
            .FirstOrDefaultAsync(c => c.ClaimNumber == claimNumber, cancellationToken);
    }

    public async Task<IReadOnlyList<InsuranceClaim>> GetByShipmentIdAsync(
        Guid shipmentId,
        CancellationToken cancellationToken = default)
    {
        return await _context.InsuranceClaims
            .Where(c => c.ShipmentId == shipmentId)
            .OrderByDescending(c => c.SubmittedAt)
            .ToListAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<InsuranceClaim>> GetByCustomerIdAsync(
        Guid customerId,
        CancellationToken cancellationToken = default)
    {
        return await _context.InsuranceClaims
            .Where(c => c.CustomerId == customerId)
            .OrderByDescending(c => c.SubmittedAt)
            .ToListAsync(cancellationToken);
    }

    public async Task<IReadOnlyList<InsuranceClaim>> GetByStatusAsync(
        ClaimStatus status,
        CancellationToken cancellationToken = default)
    {
        return await _context.InsuranceClaims
            .Where(c => c.Status == status)
            .OrderBy(c => c.SubmittedAt)  // oldest first (FIFO review)
            .ToListAsync(cancellationToken);
    }

    public async Task AddAsync(InsuranceClaim claim, CancellationToken cancellationToken = default)
    {
        await _context.InsuranceClaims.AddAsync(claim, cancellationToken);
    }

    public void Update(InsuranceClaim claim)
    {
        _context.InsuranceClaims.Update(claim);
    }
}
