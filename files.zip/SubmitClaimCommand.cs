using SLFMS.Application.Common.Abstractions;
using SLFMS.Application.Common.Models;
using SLFMS.Domain.Claims;
using SLFMS.Domain.Claims.ValueObjects;
using SLFMS.Domain.SharedKernel;
using FluentValidation;

namespace SLFMS.Application.Claims.Commands.SubmitClaim;

// ======================== Command ========================

public sealed record SubmitClaimCommand(
    Guid ShipmentId,
    Guid CustomerId,
    decimal ClaimAmount,
    string Currency,
    string Description,
    string? DocumentFileName,
    string? DocumentFileUrl,
    string? DocumentContentType,
    long? DocumentFileSizeBytes
) : ICommand<Result<Guid>>;

// ======================== Handler ========================

public sealed class SubmitClaimHandler : ICommandHandler<SubmitClaimCommand, Result<Guid>>
{
    private readonly IClaimRepository _repository;
    private readonly IUnitOfWork _unitOfWork;

    public SubmitClaimHandler(IClaimRepository repository, IUnitOfWork unitOfWork)
    {
        _repository = repository;
        _unitOfWork = unitOfWork;
    }

    public async Task<Result<Guid>> Handle(SubmitClaimCommand command, CancellationToken cancellationToken)
    {
        var claimAmount = Money.Of(command.ClaimAmount, command.Currency);

        ClaimDocument? document = null;
        if (command.DocumentFileName is not null &&
            command.DocumentFileUrl is not null &&
            command.DocumentContentType is not null &&
            command.DocumentFileSizeBytes is not null)
        {
            document = ClaimDocument.Create(
                command.DocumentFileName,
                command.DocumentFileUrl,
                command.DocumentContentType,
                command.DocumentFileSizeBytes.Value);
        }

        var claim = InsuranceClaim.Submit(
            command.ShipmentId,
            command.CustomerId,
            claimAmount,
            command.Description,
            document);

        await _repository.AddAsync(claim, cancellationToken);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return Result.Success(claim.Id.Value);
    }
}

// ======================== Validator ========================

public sealed class SubmitClaimValidator : AbstractValidator<SubmitClaimCommand>
{
    public SubmitClaimValidator()
    {
        RuleFor(x => x.ShipmentId)
            .NotEmpty().WithMessage("Shipment ID is required.");

        RuleFor(x => x.CustomerId)
            .NotEmpty().WithMessage("Customer ID is required.");

        RuleFor(x => x.ClaimAmount)
            .GreaterThan(0).WithMessage("Claim amount must be greater than zero.");

        RuleFor(x => x.Currency)
            .NotEmpty().WithMessage("Currency is required.")
            .Length(3).WithMessage("Currency must be a 3-letter ISO code.");

        RuleFor(x => x.Description)
            .NotEmpty().WithMessage("Description is required.")
            .MaximumLength(1000).WithMessage("Description cannot exceed 1000 characters.");

        // If any document field is provided, all must be provided
        When(x => x.DocumentFileName is not null, () =>
        {
            RuleFor(x => x.DocumentFileUrl).NotEmpty().WithMessage("Document URL is required.");
            RuleFor(x => x.DocumentContentType).NotEmpty().WithMessage("Document content type is required.");
            RuleFor(x => x.DocumentFileSizeBytes).GreaterThan(0).WithMessage("Document file size must be greater than zero.");
        });
    }
}
