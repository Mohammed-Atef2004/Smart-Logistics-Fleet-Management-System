using MediatR;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Routing;
using SLFMS.Application.Claims.Commands.ApproveClaim;
using SLFMS.Application.Claims.Commands.ProcessClaimPayment;
using SLFMS.Application.Claims.Commands.RejectClaim;
using SLFMS.Application.Claims.Commands.SubmitClaim;
using SLFMS.Application.Claims.Queries;
using SLFMS.Application.Claims.Queries.GetClaimDetails;
using SLFMS.Application.Claims.Queries.GetClaimsByStatus;
using SLFMS.Application.Claims.Queries.GetPendingClaims;
using SLFMS.Domain.Claims.Enums;

namespace SLFMS.API.Endpoints;

public static class ClaimEndpoints
{
    public static void MapClaimEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/api/claims")
            .WithTags("Insurance Claims")
            .RequireAuthorization();

        // =========================================================
        // COMMANDS
        // =========================================================

        // POST /api/claims/submit
        group.MapPost("/submit", async (
            SubmitClaimCommand command,
            ISender sender,
            CancellationToken ct) =>
        {
            var result = await sender.Send(command, ct);
            return result.IsSuccess
                ? Results.Created($"/api/claims/{result.Value}", new { id = result.Value })
                : Results.BadRequest(result.Error);
        })
        .WithName("SubmitClaim")
        .Produces<object>(StatusCodes.Status201Created)
        .Produces(StatusCodes.Status400BadRequest)
        .WithSummary("Submit a new insurance claim for a shipment");

        // PUT /api/claims/{id}/start-review
        group.MapPut("/{id:guid}/start-review", async (
            Guid id,
            ISender sender,
            CancellationToken ct) =>
        {
            // StartReview is a simple state transition - no extra payload needed
            // We handle this through a dedicated lightweight command
            var result = await sender.Send(new StartClaimReviewCommand(id), ct);
            return result.IsSuccess
                ? Results.NoContent()
                : Results.BadRequest(result.Error);
        })
        .WithName("StartClaimReview")
        .Produces(StatusCodes.Status204NoContent)
        .Produces(StatusCodes.Status400BadRequest)
        .WithSummary("Move claim to Under Review status");

        // PUT /api/claims/{id}/approve
        group.MapPut("/{id:guid}/approve", async (
            Guid id,
            ApproveClaimRequest request,
            ISender sender,
            CancellationToken ct) =>
        {
            var command = new ApproveClaimCommand(id, request.ApprovedAmount, request.Currency);
            var result = await sender.Send(command, ct);
            return result.IsSuccess
                ? Results.NoContent()
                : Results.BadRequest(result.Error);
        })
        .WithName("ApproveClaim")
        .Produces(StatusCodes.Status204NoContent)
        .Produces(StatusCodes.Status400BadRequest)
        .WithSummary("Approve a claim with a specified approved amount");

        // PUT /api/claims/{id}/reject
        group.MapPut("/{id:guid}/reject", async (
            Guid id,
            RejectClaimRequest request,
            ISender sender,
            CancellationToken ct) =>
        {
            var command = new RejectClaimCommand(id, request.Reason);
            var result = await sender.Send(command, ct);
            return result.IsSuccess
                ? Results.NoContent()
                : Results.BadRequest(result.Error);
        })
        .WithName("RejectClaim")
        .Produces(StatusCodes.Status204NoContent)
        .Produces(StatusCodes.Status400BadRequest)
        .WithSummary("Reject a claim with a specified reason");

        // PUT /api/claims/{id}/process-payment
        group.MapPut("/{id:guid}/process-payment", async (
            Guid id,
            ISender sender,
            CancellationToken ct) =>
        {
            var result = await sender.Send(new ProcessClaimPaymentCommand(id), ct);
            return result.IsSuccess
                ? Results.NoContent()
                : Results.BadRequest(result.Error);
        })
        .WithName("ProcessClaimPayment")
        .Produces(StatusCodes.Status204NoContent)
        .Produces(StatusCodes.Status400BadRequest)
        .WithSummary("Process payment for an approved claim");

        // =========================================================
        // QUERIES
        // =========================================================

        // GET /api/claims/{id}
        group.MapGet("/{id:guid}", async (
            Guid id,
            ISender sender,
            CancellationToken ct) =>
        {
            var result = await sender.Send(new GetClaimDetailsQuery(id), ct);
            return result.IsSuccess
                ? Results.Ok(result.Value)
                : Results.NotFound(result.Error);
        })
        .WithName("GetClaimDetails")
        .Produces<ClaimDetailsDto>(StatusCodes.Status200OK)
        .Produces(StatusCodes.Status404NotFound)
        .WithSummary("Get full details of a specific claim");

        // GET /api/claims/pending
        group.MapGet("/pending", async (
            ISender sender,
            CancellationToken ct) =>
        {
            var result = await sender.Send(new GetPendingClaimsQuery(), ct);
            return Results.Ok(result.Value);
        })
        .WithName("GetPendingClaims")
        .Produces<IReadOnlyList<ClaimSummaryDto>>(StatusCodes.Status200OK)
        .WithSummary("Get all pending claims (Submitted + Under Review)");

        // GET /api/claims?status=Approved
        group.MapGet("/", async (
            ClaimStatus status,
            ISender sender,
            CancellationToken ct) =>
        {
            var result = await sender.Send(new GetClaimsByStatusQuery(status), ct);
            return Results.Ok(result.Value);
        })
        .WithName("GetClaimsByStatus")
        .Produces<IReadOnlyList<ClaimSummaryDto>>(StatusCodes.Status200OK)
        .WithSummary("Get claims filtered by status");
    }
}

// =========================================================
// Request Models (thin DTOs for API input)
// =========================================================

public sealed record ApproveClaimRequest(decimal ApprovedAmount, string Currency);
public sealed record RejectClaimRequest(string Reason);

// StartReview is a simple state change - inline command
public sealed record StartClaimReviewCommand(Guid ClaimId)
    : MediatR.IRequest<SLFMS.Application.Common.Models.Result>;
