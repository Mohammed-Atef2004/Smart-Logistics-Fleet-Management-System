using SLFMS.Application.Common.Abstractions;
using SLFMS.Application.Common.Models;
using SLFMS.Domain.Claims;
using SLFMS.Domain.Claims.ValueObjects;
using SLFMS.Domain.SharedKernel;
using FluentValidation;

namespace SLFMS.Application.Claims.Commands.ApproveClaim;

// ======================== Command ========================

public sealed record ApproveClaimCommand(
    Guid ClaimId,
    decimal ApprovedAmount,
    string Currency
) : ICommand<Result>;

// ======================== Handler ========================

public sealed class ApproveClaimHandler : ICommandHandler<ApproveClaimCommand, Result>
{
    private readonly IClaimRepository _repository;
    private readonly IUnitOfWork _unitOfWork;

    public ApproveClaimHandler(IClaimRepository repository, IUnitOfWork unitOfWork)
    {
        _repository = repository;
        _unitOfWork = unitOfWork;
    }

    public async Task<Result> Handle(ApproveClaimCommand command, CancellationToken cancellationToken)
    {
        var claim = await _repository.GetByIdAsync(
            ClaimId.From(command.ClaimId), cancellationToken);

        if (claim is null)
            return Result.Failure(Error.NotFound("Claim.NotFound", $"Claim '{command.ClaimId}' was not found."));

        var approvedAmount = Money.Of(command.ApprovedAmount, command.Currency);

        claim.Approve(approvedAmount);

        _repository.Update(claim);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return Result.Success();
    }
}

// ======================== Validator ========================

public sealed class ApproveClaimValidator : AbstractValidator<ApproveClaimCommand>
{
    public ApproveClaimValidator()
    {
        RuleFor(x => x.ClaimId)
            .NotEmpty().WithMessage("Claim ID is required.");

        RuleFor(x => x.ApprovedAmount)
            .GreaterThan(0).WithMessage("Approved amount must be greater than zero.");

        RuleFor(x => x.Currency)
            .NotEmpty().WithMessage("Currency is required.")
            .Length(3).WithMessage("Currency must be a 3-letter ISO code.");
    }
}
