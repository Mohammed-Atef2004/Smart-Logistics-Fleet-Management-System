using SLFMS.Domain.Claims.Enums;

namespace SLFMS.Application.Claims.Queries;

public sealed record ClaimDetailsDto(
    Guid Id,
    string ClaimNumber,
    Guid ShipmentId,
    Guid CustomerId,
    string Status,
    decimal ClaimAmount,
    string ClaimCurrency,
    decimal? ApprovedAmount,
    string? ApprovedCurrency,
    string Description,
    string? RejectionReason,
    DateTime SubmittedAt,
    DateTime? ReviewedAt,
    DateTime? ProcessedAt,
    ClaimDocumentDto? Document,
    IReadOnlyList<ClaimItemDto> Items
);

public sealed record ClaimItemDto(
    Guid Id,
    string Description,
    decimal UnitValue,
    string Currency,
    int Quantity,
    decimal TotalValue
);

public sealed record ClaimDocumentDto(
    string FileName,
    string FileUrl,
    string ContentType,
    long FileSizeBytes,
    DateTime UploadedAt
);

public sealed record ClaimSummaryDto(
    Guid Id,
    string ClaimNumber,
    Guid ShipmentId,
    Guid CustomerId,
    string Status,
    decimal ClaimAmount,
    string Currency,
    DateTime SubmittedAt
);
