using SLFMS.Domain.Claims.Enums;
using SLFMS.Domain.Claims.Events;
using SLFMS.Domain.Claims.Rules;
using SLFMS.Domain.Claims.ValueObjects;
using SLFMS.Domain.Common;
using SLFMS.Domain.SharedKernel;

namespace SLFMS.Domain.Claims;

public class InsuranceClaim : AggregateRoot
{
    private readonly List<ClaimItem> _items = new();
    public IReadOnlyList<ClaimItem> Items => _items.AsReadOnly();

    public ClaimId Id { get; private set; }
    public ClaimNumber ClaimNumber { get; private set; }
    public Guid ShipmentId { get; private set; }
    public Guid CustomerId { get; private set; }
    public ClaimStatus Status { get; private set; }
    public Money ClaimAmount { get; private set; }
    public Money? ApprovedAmount { get; private set; }
    public string Description { get; private set; }
    public ClaimDocument? SupportingDocument { get; private set; }
    public string? RejectionReason { get; private set; }
    public DateTime SubmittedAt { get; private set; }
    public DateTime? ReviewedAt { get; private set; }
    public DateTime? ProcessedAt { get; private set; }

    private InsuranceClaim() { }

    // ==================== Factory Method ====================

    public static InsuranceClaim Submit(
        Guid shipmentId,
        Guid customerId,
        Money claimAmount,
        string description,
        ClaimDocument? document = null)
    {
        if (string.IsNullOrWhiteSpace(description))
            throw new ArgumentException("Claim description is required.", nameof(description));

        var claim = new InsuranceClaim
        {
            Id = ClaimId.New(),
            ClaimNumber = ClaimNumber.Generate(),
            ShipmentId = shipmentId,
            CustomerId = customerId,
            ClaimAmount = claimAmount,
            Description = description,
            SupportingDocument = document,
            Status = ClaimStatus.Submitted,
            SubmittedAt = DateTime.UtcNow
        };

        claim.RaiseDomainEvent(new ClaimSubmittedEvent(claim.Id, shipmentId, customerId, claimAmount));
        return claim;
    }

    // ==================== Business Methods ====================

    public void AddItem(string itemDescription, Money itemValue, int quantity)
    {
        CheckRule(new ClaimMustBeInReviewableStatusRule(Status));

        var item = ClaimItem.Create(itemDescription, itemValue, quantity);
        _items.Add(item);
    }

    public void AttachDocument(ClaimDocument document)
    {
        CheckRule(new ClaimMustBeInReviewableStatusRule(Status));

        SupportingDocument = document;
    }

    public void StartReview()
    {
        CheckRule(new ClaimMustBeSubmittedRule(Status));

        Status = ClaimStatus.UnderReview;
        ReviewedAt = DateTime.UtcNow;

        RaiseDomainEvent(new ClaimUnderReviewEvent(Id));
    }

    public void Approve(Money approvedAmount)
    {
        CheckRule(new ClaimMustBeUnderReviewRule(Status));
        CheckRule(new ApprovedAmountCannotExceedClaimAmountRule(approvedAmount, ClaimAmount));

        ApprovedAmount = approvedAmount;
        Status = ClaimStatus.Approved;
        ReviewedAt = DateTime.UtcNow;

        RaiseDomainEvent(new ClaimApprovedEvent(Id, CustomerId, approvedAmount));
    }

    public void Reject(string reason)
    {
        CheckRule(new ClaimMustBeUnderReviewRule(Status));

        if (string.IsNullOrWhiteSpace(reason))
            throw new ArgumentException("Rejection reason is required.", nameof(reason));

        RejectionReason = reason;
        Status = ClaimStatus.Rejected;
        ReviewedAt = DateTime.UtcNow;

        RaiseDomainEvent(new ClaimRejectedEvent(Id, CustomerId, reason));
    }

    public void ProcessPayment()
    {
        CheckRule(new ClaimMustBeApprovedRule(Status));

        Status = ClaimStatus.PaymentProcessed;
        ProcessedAt = DateTime.UtcNow;

        RaiseDomainEvent(new ClaimPaymentProcessedEvent(Id, CustomerId, ApprovedAmount!));
    }

    public void Close()
    {
        CheckRule(new ClaimCanBeClosedRule(Status));

        Status = ClaimStatus.Closed;

        RaiseDomainEvent(new ClaimClosedEvent(Id));
    }
}
