using SLFMS.Application.Common.Abstractions;
using SLFMS.Application.Common.Models;
using SLFMS.Domain.Claims;
using SLFMS.Domain.Claims.ValueObjects;
using FluentValidation;

namespace SLFMS.Application.Claims.Commands.RejectClaim;

// ======================== Command ========================

public sealed record RejectClaimCommand(
    Guid ClaimId,
    string Reason
) : ICommand<Result>;

// ======================== Handler ========================

public sealed class RejectClaimHandler : ICommandHandler<RejectClaimCommand, Result>
{
    private readonly IClaimRepository _repository;
    private readonly IUnitOfWork _unitOfWork;

    public RejectClaimHandler(IClaimRepository repository, IUnitOfWork unitOfWork)
    {
        _repository = repository;
        _unitOfWork = unitOfWork;
    }

    public async Task<Result> Handle(RejectClaimCommand command, CancellationToken cancellationToken)
    {
        var claim = await _repository.GetByIdAsync(
            ClaimId.From(command.ClaimId), cancellationToken);

        if (claim is null)
            return Result.Failure(Error.NotFound("Claim.NotFound", $"Claim '{command.ClaimId}' was not found."));

        claim.Reject(command.Reason);

        _repository.Update(claim);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return Result.Success();
    }
}

// ======================== Validator ========================

public sealed class RejectClaimValidator : AbstractValidator<RejectClaimCommand>
{
    public RejectClaimValidator()
    {
        RuleFor(x => x.ClaimId)
            .NotEmpty().WithMessage("Claim ID is required.");

        RuleFor(x => x.Reason)
            .NotEmpty().WithMessage("Rejection reason is required.")
            .MaximumLength(500).WithMessage("Rejection reason cannot exceed 500 characters.");
    }
}
