using SLFMS.Application.Common.Interfaces;
using SLFMS.Domain.Claims.Events;
using MediatR;
using Microsoft.Extensions.Logging;

namespace SLFMS.Application.Claims.EventHandlers;

// ======================== ClaimSubmitted ========================

public sealed class ClaimSubmittedEventHandler : INotificationHandler<ClaimSubmittedEvent>
{
    private readonly IEmailService _emailService;
    private readonly ILogger<ClaimSubmittedEventHandler> _logger;

    public ClaimSubmittedEventHandler(IEmailService emailService, ILogger<ClaimSubmittedEventHandler> logger)
    {
        _emailService = emailService;
        _logger = logger;
    }

    public async Task Handle(ClaimSubmittedEvent notification, CancellationToken cancellationToken)
    {
        _logger.LogInformation(
            "Insurance claim {ClaimId} submitted for shipment {ShipmentId}. Amount: {Amount} {Currency}",
            notification.ClaimId,
            notification.ShipmentId,
            notification.ClaimAmount.Amount,
            notification.ClaimAmount.Currency);

        // Notify customer: claim received
        await _emailService.SendClaimSubmittedNotificationAsync(
            notification.CustomerId,
            notification.ClaimId.Value,
            notification.ClaimAmount,
            cancellationToken);
    }
}

// ======================== ClaimApproved ========================

public sealed class ClaimApprovedEventHandler : INotificationHandler<ClaimApprovedEvent>
{
    private readonly IEmailService _emailService;
    private readonly ILogger<ClaimApprovedEventHandler> _logger;

    public ClaimApprovedEventHandler(IEmailService emailService, ILogger<ClaimApprovedEventHandler> logger)
    {
        _emailService = emailService;
        _logger = logger;
    }

    public async Task Handle(ClaimApprovedEvent notification, CancellationToken cancellationToken)
    {
        _logger.LogInformation(
            "Insurance claim {ClaimId} approved. Approved amount: {Amount} {Currency}",
            notification.ClaimId,
            notification.ApprovedAmount.Amount,
            notification.ApprovedAmount.Currency);

        // Notify customer: claim approved
        await _emailService.SendClaimApprovedNotificationAsync(
            notification.CustomerId,
            notification.ClaimId.Value,
            notification.ApprovedAmount,
            cancellationToken);
    }
}

// ======================== ClaimRejected ========================

public sealed class ClaimRejectedEventHandler : INotificationHandler<ClaimRejectedEvent>
{
    private readonly IEmailService _emailService;
    private readonly ILogger<ClaimRejectedEventHandler> _logger;

    public ClaimRejectedEventHandler(IEmailService emailService, ILogger<ClaimRejectedEventHandler> logger)
    {
        _emailService = emailService;
        _logger = logger;
    }

    public async Task Handle(ClaimRejectedEvent notification, CancellationToken cancellationToken)
    {
        _logger.LogInformation(
            "Insurance claim {ClaimId} rejected. Reason: {Reason}",
            notification.ClaimId,
            notification.Reason);

        // Notify customer: claim rejected with reason
        await _emailService.SendClaimRejectedNotificationAsync(
            notification.CustomerId,
            notification.ClaimId.Value,
            notification.Reason,
            cancellationToken);
    }
}

// ======================== ClaimPaymentProcessed ========================

public sealed class ClaimPaymentProcessedEventHandler : INotificationHandler<ClaimPaymentProcessedEvent>
{
    private readonly IEmailService _emailService;
    private readonly ILogger<ClaimPaymentProcessedEventHandler> _logger;

    public ClaimPaymentProcessedEventHandler(IEmailService emailService, ILogger<ClaimPaymentProcessedEventHandler> logger)
    {
        _emailService = emailService;
        _logger = logger;
    }

    public async Task Handle(ClaimPaymentProcessedEvent notification, CancellationToken cancellationToken)
    {
        _logger.LogInformation(
            "Payment processed for claim {ClaimId}. Amount paid: {Amount} {Currency}",
            notification.ClaimId,
            notification.PaidAmount.Amount,
            notification.PaidAmount.Currency);

        // Notify customer: payment on the way
        await _emailService.SendClaimPaymentProcessedNotificationAsync(
            notification.CustomerId,
            notification.ClaimId.Value,
            notification.PaidAmount,
            cancellationToken);
    }
}
