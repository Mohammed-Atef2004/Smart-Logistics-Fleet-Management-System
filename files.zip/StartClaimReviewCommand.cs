using SLFMS.Application.Common.Abstractions;
using SLFMS.Application.Common.Models;
using SLFMS.Domain.Claims;
using SLFMS.Domain.Claims.ValueObjects;
using FluentValidation;

namespace SLFMS.Application.Claims.Commands.StartClaimReview;

// ======================== Command ========================

public sealed record StartClaimReviewCommand(Guid ClaimId) : ICommand<Result>;

// ======================== Handler ========================

public sealed class StartClaimReviewHandler : ICommandHandler<StartClaimReviewCommand, Result>
{
    private readonly IClaimRepository _repository;
    private readonly IUnitOfWork _unitOfWork;

    public StartClaimReviewHandler(IClaimRepository repository, IUnitOfWork unitOfWork)
    {
        _repository = repository;
        _unitOfWork = unitOfWork;
    }

    public async Task<Result> Handle(StartClaimReviewCommand command, CancellationToken cancellationToken)
    {
        var claim = await _repository.GetByIdAsync(
            ClaimId.From(command.ClaimId), cancellationToken);

        if (claim is null)
            return Result.Failure(Error.NotFound("Claim.NotFound", $"Claim '{command.ClaimId}' was not found."));

        claim.StartReview();

        _repository.Update(claim);
        await _unitOfWork.SaveChangesAsync(cancellationToken);

        return Result.Success();
    }
}

// ======================== Validator ========================

public sealed class StartClaimReviewValidator : AbstractValidator<StartClaimReviewCommand>
{
    public StartClaimReviewValidator()
    {
        RuleFor(x => x.ClaimId)
            .NotEmpty().WithMessage("Claim ID is required.");
    }
}
