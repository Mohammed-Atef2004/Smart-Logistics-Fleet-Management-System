using SLFMS.Domain.Claims.Enums;
using SLFMS.Domain.Claims.ValueObjects;

namespace SLFMS.Domain.Claims;

public interface IClaimRepository
{
    Task<InsuranceClaim?> GetByIdAsync(ClaimId id, CancellationToken cancellationToken = default);
    Task<InsuranceClaim?> GetByClaimNumberAsync(ClaimNumber claimNumber, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<InsuranceClaim>> GetByShipmentIdAsync(Guid shipmentId, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<InsuranceClaim>> GetByCustomerIdAsync(Guid customerId, CancellationToken cancellationToken = default);
    Task<IReadOnlyList<InsuranceClaim>> GetByStatusAsync(ClaimStatus status, CancellationToken cancellationToken = default);
    Task AddAsync(InsuranceClaim claim, CancellationToken cancellationToken = default);
    void Update(InsuranceClaim claim);
}
