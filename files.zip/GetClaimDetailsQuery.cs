using SLFMS.Application.Common.Abstractions;
using SLFMS.Application.Common.Models;
using SLFMS.Domain.Claims;
using SLFMS.Domain.Claims.ValueObjects;

namespace SLFMS.Application.Claims.Queries.GetClaimDetails;

// ======================== Query ========================

public sealed record GetClaimDetailsQuery(Guid ClaimId) : IQuery<Result<ClaimDetailsDto>>;

// ======================== Handler ========================

public sealed class GetClaimDetailsHandler : IQueryHandler<GetClaimDetailsQuery, Result<ClaimDetailsDto>>
{
    private readonly IClaimRepository _repository;

    public GetClaimDetailsHandler(IClaimRepository repository) => _repository = repository;

    public async Task<Result<ClaimDetailsDto>> Handle(GetClaimDetailsQuery query, CancellationToken cancellationToken)
    {
        var claim = await _repository.GetByIdAsync(
            ClaimId.From(query.ClaimId), cancellationToken);

        if (claim is null)
            return Result.Failure<ClaimDetailsDto>(
                Error.NotFound("Claim.NotFound", $"Claim '{query.ClaimId}' was not found."));

        var dto = new ClaimDetailsDto(
            Id: claim.Id.Value,
            ClaimNumber: claim.ClaimNumber.Value,
            ShipmentId: claim.ShipmentId,
            CustomerId: claim.CustomerId,
            Status: claim.Status.ToString(),
            ClaimAmount: claim.ClaimAmount.Amount,
            ClaimCurrency: claim.ClaimAmount.Currency,
            ApprovedAmount: claim.ApprovedAmount?.Amount,
            ApprovedCurrency: claim.ApprovedAmount?.Currency,
            Description: claim.Description,
            RejectionReason: claim.RejectionReason,
            SubmittedAt: claim.SubmittedAt,
            ReviewedAt: claim.ReviewedAt,
            ProcessedAt: claim.ProcessedAt,
            Document: claim.SupportingDocument is null ? null : new ClaimDocumentDto(
                claim.SupportingDocument.FileName,
                claim.SupportingDocument.FileUrl,
                claim.SupportingDocument.ContentType,
                claim.SupportingDocument.FileSizeBytes,
                claim.SupportingDocument.UploadedAt),
            Items: claim.Items.Select(i => new ClaimItemDto(
                i.Id,
                i.Description,
                i.UnitValue.Amount,
                i.UnitValue.Currency,
                i.Quantity,
                i.TotalValue.Amount)).ToList()
        );

        return Result.Success(dto);
    }
}
