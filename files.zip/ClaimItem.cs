using SLFMS.Domain.Common;
using SLFMS.Domain.SharedKernel;

namespace SLFMS.Domain.Claims;

public class ClaimItem : Entity
{
    public Guid Id { get; private set; }
    public string Description { get; private set; }
    public Money UnitValue { get; private set; }
    public int Quantity { get; private set; }
    public Money TotalValue => Money.Of(UnitValue.Amount * Quantity, UnitValue.Currency);

    private ClaimItem() { }

    internal static ClaimItem Create(string description, Money unitValue, int quantity)
    {
        if (string.IsNullOrWhiteSpace(description))
            throw new ArgumentException("Item description is required.", nameof(description));

        if (quantity <= 0)
            throw new ArgumentException("Quantity must be greater than zero.", nameof(quantity));

        return new ClaimItem
        {
            Id = Guid.NewGuid(),
            Description = description,
            UnitValue = unitValue,
            Quantity = quantity
        };
    }
}
