using SLFMS.Domain.Claims.Enums;
using SLFMS.Domain.Common;
using SLFMS.Domain.SharedKernel;

namespace SLFMS.Domain.Claims.Rules;

public sealed class ClaimMustBeSubmittedRule : IBusinessRule
{
    private readonly ClaimStatus _status;

    public ClaimMustBeSubmittedRule(ClaimStatus status) => _status = status;

    public bool IsBroken() => _status != ClaimStatus.Submitted;

    public string Message => "Claim must be in Submitted status to start review.";
}

public sealed class ClaimMustBeUnderReviewRule : IBusinessRule
{
    private readonly ClaimStatus _status;

    public ClaimMustBeUnderReviewRule(ClaimStatus status) => _status = status;

    public bool IsBroken() => _status != ClaimStatus.UnderReview;

    public string Message => "Claim must be Under Review to approve or reject.";
}

public sealed class ClaimMustBeApprovedRule : IBusinessRule
{
    private readonly ClaimStatus _status;

    public ClaimMustBeApprovedRule(ClaimStatus status) => _status = status;

    public bool IsBroken() => _status != ClaimStatus.Approved;

    public string Message => "Claim must be Approved before processing payment.";
}

public sealed class ClaimMustBeInReviewableStatusRule : IBusinessRule
{
    private readonly ClaimStatus _status;

    public ClaimMustBeInReviewableStatusRule(ClaimStatus status) => _status = status;

    public bool IsBroken() => _status is not (ClaimStatus.Submitted or ClaimStatus.UnderReview);

    public string Message => "Claim items or documents can only be modified when Submitted or Under Review.";
}

public sealed class ClaimCanBeClosedRule : IBusinessRule
{
    private readonly ClaimStatus _status;

    public ClaimCanBeClosedRule(ClaimStatus status) => _status = status;

    public bool IsBroken() => _status is not (ClaimStatus.Rejected or ClaimStatus.PaymentProcessed);

    public string Message => "Only Rejected or Payment Processed claims can be closed.";
}

public sealed class ApprovedAmountCannotExceedClaimAmountRule : IBusinessRule
{
    private readonly Money _approvedAmount;
    private readonly Money _claimAmount;

    public ApprovedAmountCannotExceedClaimAmountRule(Money approvedAmount, Money claimAmount)
    {
        _approvedAmount = approvedAmount;
        _claimAmount = claimAmount;
    }

    public bool IsBroken() => _approvedAmount.Amount > _claimAmount.Amount;

    public string Message => $"Approved amount ({_approvedAmount}) cannot exceed claimed amount ({_claimAmount}).";
}
